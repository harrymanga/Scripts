import os
import platform
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import messagebox, filedialog

# Intentar importar watchdog, si no está, instalarlo
def instalar_watchdog():
    try:
        import watchdog
    except ImportError:
        respuesta = messagebox.askyesno(
            "Instalar dependencia",
            "La librería 'watchdog' no está instalada.\n¿Quieres instalarla ahora?"
        )
        if respuesta:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "watchdog"])
        else:
            messagebox.showerror("Error", "La librería watchdog es necesaria. Cerrando programa.")
            sys.exit()

instalar_watchdog()
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler


def detectar_distro_linux():
    try:
        with open("/etc/os-release") as f:
            lines = f.readlines()
        info = {}
        for line in lines:
            if "=" in line:
                k, v = line.strip().split("=", 1)
                info[k] = v.strip('"')
        return info.get("ID", "").lower()
    except Exception:
        return ""


def instalar_rsync_linux():
    distro = detectar_distro_linux()
    if subprocess.call(["which", "rsync"], stdout=subprocess.DEVNULL) == 0:
        return  # rsync ya instalado

    gestores = {
        "ubuntu": ["sudo", "apt-get", "install", "-y", "rsync"],
        "debian": ["sudo", "apt-get", "install", "-y", "rsync"],
        "fedora": ["sudo", "dnf", "install", "-y", "rsync"],
        "centos": ["sudo", "yum", "install", "-y", "rsync"],
        "arch": ["sudo", "pacman", "-Sy", "rsync"],
        "opensuse": ["sudo", "zypper", "install", "-y", "rsync"],
    }

    comando = gestores.get(distro)
    if comando is None:
        messagebox.showwarning(
            "Aviso",
            f"No se pudo detectar o no está soportada la distro '{distro}'.\n"
            "Por favor instala rsync manualmente."
        )
        sys.exit()

    respuesta = messagebox.askyesno(
        "Instalar rsync",
        f"No se encontró 'rsync' instalado.\n¿Quieres instalarlo ahora con '{' '.join(comando)}'?"
    )
    if respuesta:
        try:
            subprocess.check_call(comando)
            messagebox.showinfo("Éxito", "rsync instalado correctamente.")
        except Exception as e:
            messagebox.showerror("Error", f"No se pudo instalar rsync automáticamente:\n{e}")
            sys.exit()
    else:
        messagebox.showerror("Error", "rsync es necesario para la sincronización. Cerrando programa.")
        sys.exit()


def comprobar_instalar_rsync():
    sistema = platform.system()
    if sistema in ["Linux", "Darwin"]:
        instalar_rsync_linux()
    elif sistema == "Windows":
        # robocopy viene preinstalado
        pass
    else:
        messagebox.showerror("Error", f"Sistema operativo {sistema} no soportado.")
        sys.exit()


class CambioHandler(FileSystemEventHandler):
    def __init__(self, origen, destinos):
        self.origen = origen
        self.destinos = destinos

    def on_any_event(self, event):
        sync(self.origen, self.destinos)


def sync(origen, destinos):
    sistema = platform.system()
    for dest in destinos:
        if sistema in ["Linux", "Darwin"]:
            cmd = ["rsync", "-av", "--delete", origen + "/", dest + "/"]
        elif sistema == "Windows":
            cmd = ["robocopy", origen, dest, "/MIR", "/NFL", "/NDL"]
        else:
            messagebox.showerror("Error", f"Sistema operativo {sistema} no soportado.")
            return

        try:
            resultado = subprocess.run(cmd, capture_output=True, text=True)
            print(resultado.stdout)
        except Exception as e:
            messagebox.showerror("Error", f"Error al sincronizar: {e}")

    status_label.config(text="Sincronización completa.")


def iniciar_monitor():
    origen = origen_entry.get()
    destinos = destinos_text.get("1.0", tk.END).strip().split('\n')

    if not os.path.exists(origen):
        messagebox.showerror("Error", "La carpeta origen no existe.")
        return
    for d in destinos:
        if not os.path.exists(d):
            messagebox.showwarning("Advertencia", f"La carpeta destino {d} no existe.")

    global observer
    if 'observer' in globals():
        observer.stop()
        observer.join()

    event_handler = CambioHandler(origen, destinos)
    observer = Observer()
    observer.schedule(event_handler, path=origen, recursive=True)
    observer.start()

    status_label.config(text="Monitoreando cambios...")

    def run_observer():
        try:
            while True:
                pass
        except KeyboardInterrupt:
            observer.stop()
        observer.join()

    threading.Thread(target=run_observer, daemon=True).start()


# --- INTERFAZ GRÁFICA ---
root = tk.Tk()
root.title("Sincronizador Automático de Carpetas")

tk.Label(root, text="Carpeta Origen:").pack(pady=(10,0))
origen_entry = tk.Entry(root, width=50)
origen_entry.pack(pady=(0,5))
tk.Button(root, text="Seleccionar Origen", command=lambda: origen_entry.delete(0, tk.END) or origen_entry.insert(0, filedialog.askdirectory())).pack()

tk.Label(root, text="Carpetas Destino (una por línea):").pack(pady=(10,0))
destinos_text = tk.Text(root, height=5, width=50)
destinos_text.pack()
tk.Button(root, text="Iniciar Monitoreo", command=iniciar_monitor).pack(pady=10)

status_label = tk.Label(root, text="")
status_label.pack()

# Al iniciar, comprobar rsync/robocopy
comprobar_instalar_rsync()

root.mainloop()