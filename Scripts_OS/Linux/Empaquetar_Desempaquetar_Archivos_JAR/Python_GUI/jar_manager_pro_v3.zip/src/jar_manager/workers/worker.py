
from PySide6.QtCore import QObject, Signal
from pathlib import Path
import subprocess

class JarWorker(QObject):

    progress = Signal(int)
    current_file = Signal(str)
    finished = Signal(str)

    def __init__(self, files, destination, mode):
        super().__init__()
        self.files = files
        self.destination = Path(destination)
        self.mode = mode
        self._cancel = False

    def cancel(self):
        self._cancel = True

    def run(self):
        total = len(self.files)

        for i, file in enumerate(self.files):
            if self._cancel:
                self.finished.emit("Proceso cancelado")
                return

            path = Path(file)
            self.current_file.emit(f"Procesando: {path.name}")

            if self.mode == "Desempaquetar":
                output_folder = self.destination / path.stem
                output_folder.mkdir(parents=True, exist_ok=True)
                subprocess.run(["jar", "xf", str(path)], cwd=output_folder)
            else:
                output_file = self.destination / f"{path.name}.jar"
                subprocess.run(["jar", "cf", str(output_file), "-C", str(path), "."])

            percent = int(((i + 1) / total) * 100)
            self.progress.emit(percent)

        self.finished.emit("Proceso completado correctamente")
