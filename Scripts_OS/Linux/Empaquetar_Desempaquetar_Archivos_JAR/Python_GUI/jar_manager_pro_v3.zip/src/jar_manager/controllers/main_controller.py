
from PySide6.QtWidgets import QFileDialog
from PySide6.QtCore import QThread
from jar_manager.workers.worker import JarWorker

class MainController:

    def __init__(self, view):
        self.view = view
        self._connect_signals()

    def _connect_signals(self):
        self.view.ui.browseJarBtn.clicked.connect(self.browse_input)
        self.view.ui.browseOutputBtn.clicked.connect(self.browse_output)
        self.view.ui.executeBtn.clicked.connect(self.execute)
        self.view.ui.cancelBtn.clicked.connect(self.cancel)

    def browse_input(self):
        files, _ = QFileDialog.getOpenFileNames(
            self.view, "Seleccionar archivos JAR", "", "JAR Files (*.jar)"
        )
        if files:
            self.view.ui.inputPathEdit.setText(";".join(files))

    def browse_output(self):
        folder = QFileDialog.getExistingDirectory(self.view, "Seleccionar destino")
        if folder:
            self.view.ui.outputPathEdit.setText(folder)

    def execute(self):
        inputs = self.view.ui.inputPathEdit.text().split(";")
        output = self.view.ui.outputPathEdit.text()
        mode = self.view.ui.modeComboBox.currentText()

        self.thread = QThread()
        self.worker = JarWorker(inputs, output, mode)
        self.worker.moveToThread(self.thread)

        self.thread.started.connect(self.worker.run)
        self.worker.progress.connect(self.view.ui.progressBar.setValue)
        self.worker.current_file.connect(self.view.ui.statusLabel.setText)
        self.worker.finished.connect(self.thread.quit)
        self.worker.finished.connect(self.view.ui.statusLabel.setText)

        self.thread.start()

    def cancel(self):
        if hasattr(self, "worker"):
            self.worker.cancel()
