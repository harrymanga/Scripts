
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QLineEdit, QComboBox,
    QProgressBar
)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setWindowTitle("Jar Manager Pro 3.0")
        MainWindow.resize(600, 300)

        central = QWidget(MainWindow)
        MainWindow.setCentralWidget(central)

        layout = QVBoxLayout(central)

        self.modeComboBox = QComboBox()
        self.modeComboBox.addItems(["Desempaquetar", "Empaquetar"])

        self.inputPathEdit = QLineEdit()
        self.outputPathEdit = QLineEdit()

        self.browseJarBtn = QPushButton("Examinar Entrada")
        self.browseOutputBtn = QPushButton("Examinar Destino")

        self.executeBtn = QPushButton("Ejecutar")
        self.cancelBtn = QPushButton("Cancelar")
        self.cancelBtn.setEnabled(False)

        self.statusLabel = QLabel("")
        self.progressBar = QProgressBar()
        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(100)
        self.progressBar.setValue(0)

        layout.addWidget(self.modeComboBox)
        layout.addWidget(self.inputPathEdit)
        layout.addWidget(self.browseJarBtn)
        layout.addWidget(self.outputPathEdit)
        layout.addWidget(self.browseOutputBtn)
        layout.addWidget(self.progressBar)
        layout.addWidget(self.statusLabel)

        buttons = QHBoxLayout()
        buttons.addWidget(self.executeBtn)
        buttons.addWidget(self.cancelBtn)

        layout.addLayout(buttons)
