
from PySide6.QtWidgets import QMainWindow
from jar_manager.ui.ui_main_window import Ui_MainWindow
from jar_manager.controllers.main_controller import MainController

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.controller = MainController(self)
