#!/usr/bin/env bash

###############################################################################
# START SCRIPT PROFESIONAL (FULL VERSION)
###############################################################################

# Detectar ruta del script
SCRIPT_PATH="$(readlink -f "$0")"
BASE_DIR="$(dirname "$SCRIPT_PATH")"

# Carga el entorno
ENV=${1:-prod}

COMMON_ENV="$BASE_DIR/conf/common.env"
ENV_FILE="$BASE_DIR/conf/$ENV.env"

if [[ ! -f "$COMMON_ENV" ]]; then
    echo "ERROR: No se encontró $COMMON_ENV"
    exit 1
fi

if [[ ! -f "$ENV_FILE" ]]; then
    echo "ERROR: No se encontró $ENV_FILE"
    exit 1
fi

source "$COMMON_ENV"
source "$ENV_FILE"

PID_FILE="$BASE_DIR/$APP_NAME.pid"
LOG_DIR="$BASE_DIR/logs"
LOG_FILE="$LOG_DIR/$APP_NAME-$(date '+%Y%m%d').log"

mkdir -p "$LOG_DIR"


############################################
# Resolver intérprete
############################################
resolve_interpreter() {
    echo "Buscando intérprete: $APP_INTER"

    if command -v "$APP_INTER" >/dev/null 2>&1; then
        return 0
    fi

    for sub in . bin app run; do
        if [[ -x "$BASE_DIR/$sub/$APP_INTER" ]]; then
            export PATH="$BASE_DIR/$sub:$PATH"
            return 0
        fi
    done

    echo "ERROR: Intérprete '$APP_INTER' no encontrado."
    exit 1
}

############################################
# Resolver archivo ejecutable
############################################
resolve_executable() {
    local file="$APP_EXEC"

    [[ "$file" = /* ]] && return 0

    for sub in . bin app run ; do
        if [[ -f "$BASE_DIR/$sub/$file" ]]; then
            APP_EXEC="$BASE_DIR/$sub/$file"
            return 0
        fi
    done

    echo "ERROR: Archivo ejecutable $file no encontrado."
    exit 1
}

############################################
# Verificar si ya está corriendo
############################################
is_running() {
    [[ -f "$PID_FILE" ]] || return 1
    PID=$(cat "$PID_FILE")
    ps -p "$PID" >/dev/null 2>&1
}


############################################
# Iniciar aplicación
############################################
start_app() {
    if is_running; then
        echo "La aplicación ya está ejecutándose (PID=$(cat "$PID_FILE"))"
        exit 0
    fi

    resolve_interpreter
    resolve_executable

    FULL_CMD="$APP_INTER $INTER_ARGS $APP_EXEC $APP_ARGS"

    echo "Ejecutando: $FULL_CMD"
    nohup bash -c "$FULL_CMD" >> "$LOG_FILE" 2>&1 &
    PID=$!
    echo "$PID" > "$PID_FILE"

    echo "Aplicación iniciada con PID: $PID"
}

start_app

