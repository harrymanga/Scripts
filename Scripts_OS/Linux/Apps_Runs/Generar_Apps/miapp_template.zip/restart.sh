#!/usr/bin/env bash

SCRIPT_PATH="$(readlink -f "$0")"
BASE_DIR="$(dirname "$SCRIPT_PATH")"

"$BASE_DIR/stop.sh"
sleep 1
"$BASE_DIR/start.sh" "$1"

