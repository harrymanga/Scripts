#!/usr/bin/env bash

echo "Desinstalando MiAplicacion..."

SCRIPT_PATH="$(readlink -f "$0")"
BASE_DIR="$(dirname "$SCRIPT_PATH")"

rm -f "$BASE_DIR/$APP_NAME.pid"

echo "Desinstalación completa."

