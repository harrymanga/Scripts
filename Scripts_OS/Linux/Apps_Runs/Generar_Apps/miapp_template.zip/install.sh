#!/usr/bin/env bash

echo "Instalando MiAplicacion..."

SCRIPT_PATH="$(readlink -f "$0")"
BASE_DIR="$(dirname "$SCRIPT_PATH")"

chmod +x "$BASE_DIR/start.sh"
chmod +x "$BASE_DIR/stop.sh"
chmod +x "$BASE_DIR/restart.sh"

mkdir -p "$BASE_DIR/logs"

echo "Instalación completa."

