#!/usr/bin/env bash

SCRIPT_PATH="$(readlink -f "$0")"
BASE_DIR="$(dirname "$SCRIPT_PATH")"
COMMON_ENV="$BASE_DIR/conf/common.env"

source "$COMMON_ENV"
PID_FILE="$BASE_DIR/$APP_NAME.pid"

stop_app() {
    if [[ ! -f "$PID_FILE" ]]; then
        echo "No hay PID. App no está corriendo."
        exit 0
    fi

    PID=$(cat "$PID_FILE")

    if ps -p "$PID" >/dev/null 2>&1; then
        echo "Deteniendo aplicación PID=$PID..."
        kill "$PID"
        rm -f "$PID_FILE"
        echo "Aplicación detenida."
    else
        echo "El PID registrado no existe. Limpiando PID_FILE."
        rm -f "$PID_FILE"
    fi
}

stop_app

