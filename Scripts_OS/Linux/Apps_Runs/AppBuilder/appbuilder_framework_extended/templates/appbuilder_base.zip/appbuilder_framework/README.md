# AppBuilder Framework

GUI tool to scaffold, configure and package service-like applications.
Built with Python + Tkinter.

## Quick start

1. Unzip the framework.
2. Run `./appbuilder.py` (requires python3 and tkinter).
3. Fill the form and click *Crear Aplicación*.

## Structure

- templates/miapp_template.zip  -> base project template
- core/                        -> generator and helpers
- appbuilder.py                -> GUI front-end


