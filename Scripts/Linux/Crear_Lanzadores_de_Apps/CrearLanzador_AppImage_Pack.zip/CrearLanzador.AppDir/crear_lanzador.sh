#!/bin/bash
if ! command -v zenity &> /dev/null; then
    echo "Zenity no está instalado. Por favor, instálalo para continuar."
    exit 1
fi

ejecutable=$(zenity --file-selection --title="Selecciona el ejecutable de la aplicación")
if [[ -z "$ejecutable" ]]; then
    zenity --error --text="No se seleccionó ningún ejecutable"
    exit 1
fi

nombre_app=$(zenity --entry --title="Nombre del lanzador" --text="Escribe el nombre del lanzador")
if [[ -z "$nombre_app" ]]; then
    zenity --error --text="No se proporcionó nombre"
    exit 1
fi

icono=$(zenity --file-selection --title="Selecciona el ícono (opcional)" --file-filter="*.png *.svg *.xpm")

categoria=$(zenity --list --checklist   --title="Selecciona categorías"   --text="Selecciona una o más categorías"   --column="Seleccionado" --column="Categoría"   TRUE Utility   FALSE Development   FALSE Game   FALSE AudioVideo   FALSE Network   FALSE Office   FALSE Settings   FALSE Education   FALSE Graphics   FALSE System   --separator=";")

[ -z "$categoria" ] && categoria="Utility"

archivo_desktop="$HOME/.local/share/applications/$nombre_app.desktop"
mkdir -p "$(dirname "$archivo_desktop")"
cat <<EOF > "$archivo_desktop"
[Desktop Entry]
Version=1.0
Type=Application
Name=$nombre_app
Exec="$ejecutable"
Icon=${icono:-application-default-icon}
Terminal=false
Categories=$categoria;
EOF

chmod +x "$archivo_desktop"

zenity --question --title="Acceso directo" --text="¿Deseas crear también un acceso directo en el escritorio?"
if [[ $? -eq 0 ]]; then
    escritorio_dir="$HOME/Escritorio"
    [ ! -d "$escritorio_dir" ] && escritorio_dir="$HOME/Desktop"
    if [ -d "$escritorio_dir" ]; then
        cp "$archivo_desktop" "$escritorio_dir/"
        chmod +x "$escritorio_dir/$nombre_app.desktop"
        command -v gio &> /dev/null && gio set "$escritorio_dir/$nombre_app.desktop" "metadata::trusted" true 2>/dev/null
    fi
fi

zenity --info --text="✅ Lanzador creado: $archivo_desktop"
